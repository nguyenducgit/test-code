! function($, window, document, _undefined)
{
	// TODO

	// *********************************************************************

	XenForo.register('.WidgetFramework_WidgetRenderer_ProfilePosts form.statusPoster', 'XenForo.ProfilePoster');
	XenForo.register('.WidgetFramework_WidgetRenderer_RecentStatus form.statusPoster', 'XenForo.ProfilePoster');
}(jQuery, this, document); 